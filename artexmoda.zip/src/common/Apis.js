export const API_URL = "https://test.artexmoda.com/brands/server/Api";

export const API_URL_LOGIN = `${API_URL}/Auth/login_api.php`;
export const API_URL_REGISTER = `${API_URL}/Auth/register_api.php`;

// Upload Products
export const API_URL_UPLOAD_PRODUCTS = `${API_URL}/st1_upload_api.php`;

// Sidebar Role
export const API_URL_SIDEBAR_PAGES = `${API_URL}/sidebar_api.php`;
