import React from "react";
import { Soon } from "../../../../components";

const UploadImage = () => {
	return (
		<>
			<Soon />
		</>
	);
};

export default UploadImage;
