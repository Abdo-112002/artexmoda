import React from "react";
import { Soon } from "../../../../components";

const Preorders = () => {
	return (
		<>
			<Soon />
		</>
	);
};

export default Preorders;
