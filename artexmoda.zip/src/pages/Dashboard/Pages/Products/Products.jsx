import React from "react";
import { Soon } from "../../../../components";

const Products = () => {
	return (
		<>
			<Soon />
		</>
	);
};

export default Products;
