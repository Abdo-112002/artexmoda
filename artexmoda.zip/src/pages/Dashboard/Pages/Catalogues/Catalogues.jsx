import React from "react";
import { Soon } from "../../../../components";

const Catalogues = () => {
	return (
		<>
			<Soon />
		</>
	);
};

export default Catalogues;
