import React from "react";
import { Soon } from "../../../../components";

const PriceList = () => {
	return (
		<>
			<Soon />
		</>
	);
};

export default PriceList;
