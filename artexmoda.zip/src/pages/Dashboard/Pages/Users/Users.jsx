import React from "react";
import { Soon } from "../../../../components";

const Users = () => {
	return (
		<>
			<Soon />
		</>
	);
};

export default Users;
