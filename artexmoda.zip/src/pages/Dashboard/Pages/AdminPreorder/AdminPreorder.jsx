import React from "react";
import { Soon } from "../../../../components";

const AdminPreorder = () => {
	return (
		<>
			<Soon />
		</>
	);
};

export default AdminPreorder;
