import React from "react";
import { Soon } from "../../../../components";

const Clients = () => {
	return (
		<>
			<Soon />
		</>
	);
};

export default Clients;
