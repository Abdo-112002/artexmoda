import React from "react";
import { Soon } from "../../../../components";

const Dashboard = () => {
	return (
		<>
			<Soon />
		</>
	);
};

export default Dashboard;
