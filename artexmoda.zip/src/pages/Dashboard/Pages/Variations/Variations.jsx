import React from "react";
import { Soon } from "../../../../components";

const Variations = () => {
	return (
		<>
			<Soon />
		</>
	);
};

export default Variations;
